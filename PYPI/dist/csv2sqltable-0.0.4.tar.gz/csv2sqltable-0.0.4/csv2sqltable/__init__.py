
# import csv2sqltable.convert as c2s
# print(c2s.transform('customer.csv'))
